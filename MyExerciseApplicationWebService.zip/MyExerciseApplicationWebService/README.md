The ROOT.war (i.e. exerciseapp.war) is available at:
/workspaces/Exercise-Application-Dashboard/tomcat/webapps/exerciseapp.war
