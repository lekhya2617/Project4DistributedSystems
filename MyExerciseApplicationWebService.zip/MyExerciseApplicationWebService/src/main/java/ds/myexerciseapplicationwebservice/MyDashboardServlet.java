// Author: Lekhya Reddy Rachapalli (lrachapa)

package ds.myexerciseapplicationwebservice;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import org.bson.Document;

import java.io.IOException;
import java.util.*;

@WebServlet(name = "DashboardServlet", urlPatterns = {"/dashboard"})
public class MyDashboardServlet extends HttpServlet {

    private static final String MONGODB_URI =
            "mongodb+srv://lrachapa_db_user:nDEBs1z3gkAR50li@exerciseapp.yyjqpds.mongodb.net/?appName=ExerciseApp";

    private static final String DB_NAME = "myexerciseapplication_db";
    private static final String COLLECTION_NAME = "myexerciseapplication_logs";

    private MongoClient mongoClient;
    private MongoCollection<Document> logCollection;

    @Override
    public void init() throws ServletException {
        // build client settings and connect to the cluster
        ConnectionString cs = new ConnectionString(MONGODB_URI);
        MongoClientSettings settings = MongoClientSettings.builder()
                .applyConnectionString(cs)
                .build();
        mongoClient = MongoClients.create(settings);
        // get the db and logs collection
        MongoDatabase db = mongoClient.getDatabase(DB_NAME);
        logCollection = db.getCollection(COLLECTION_NAME);
    }

    @Override
    public void destroy() {
        if (mongoClient != null) mongoClient.close();
        super.destroy();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        if (logCollection == null) {
            req.setAttribute("error", "Unable to connect to MongoDB.");
            req.getRequestDispatcher("/dashboard.jsp").forward(req, resp);
            return;
        }

        // last 25 logs
        List<Document> logs = logCollection.find()
                .sort(new Document("timestamp", -1))
                .limit(25)
                .into(new ArrayList<>());

        // counters and aggregators for analytics
        int totalRequests = logs.size();
        long totalLatency = 0;

        Map<String, Integer> muscleCounts = new HashMap<>();
        Map<String, Integer> equipmentCounts = new HashMap<>();

        // aggregate metrics from each log entry
        for (Document d : logs) {
            Number lat = (Number) d.get("latencyMs");
            if (lat != null) totalLatency += lat.longValue();

            String muscle = d.getString("muscle");
            if (muscle != null)
                muscleCounts.put(muscle, muscleCounts.getOrDefault(muscle, 0) + 1);

            String equip = d.getString("equipment");
            if (equip != null)
                equipmentCounts.put(equip, equipmentCounts.getOrDefault(equip, 0) + 1);
        }

        // avg latency per request in ms
        double avgLatency = (totalRequests > 0)
                ? (double) totalLatency / totalRequests
                : 0;

        // muscles sorted by req count: high to low
        List<Map.Entry<String, Integer>> topMuscles =
                new ArrayList<>(muscleCounts.entrySet());
        topMuscles.sort((a, b) -> b.getValue() - a.getValue());
        if (topMuscles.size() > 3)
            topMuscles = topMuscles.subList(0, 3);

        // equipment sorted by req count: high to low
        List<Map.Entry<String, Integer>> topEquipment =
                new ArrayList<>(equipmentCounts.entrySet());
        topEquipment.sort((a, b) -> b.getValue() - a.getValue());
        if (topEquipment.size() > 3)
            topEquipment = topEquipment.subList(0, 3);

        req.setAttribute("logs", logs);
        req.setAttribute("totalRequests", totalRequests);
        req.setAttribute("avgLatency", avgLatency);
        req.setAttribute("topMuscles", topMuscles);
        req.setAttribute("topEquipment", topEquipment);

        // forward to jsp view
        req.getRequestDispatcher("/dashboard.jsp").forward(req, resp);
    }
}