// Author: Lekhya Reddy Rachapalli (lrachapa)

package ds.myexerciseapplicationwebservice;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import java.time.Instant;

@WebServlet(name = "MyExerciseServlet", urlPatterns = {"/api/exercises"})
public class MyExerciseServlet extends HttpServlet {

    private static final String EXERCISEDB_FILTER_URL =
            "https://www.exercisedb.dev/api/v1/exercises/filter";

    private static final String MONGODB_URI =
            "mongodb+srv://lrachapa_db_user:nDEBs1z3gkAR50li@exerciseapp.yyjqpds.mongodb.net/?appName=ExerciseApp";
    private static final String DB_NAME = "myexerciseapplication_db";
    private static final String COLLECTION_NAME = "myexerciseapplication_logs";

    // mongo client and collection logging
    private MongoClient mongoClient;
    private MongoCollection<Document> logCollection;

    @Override
    public void init() throws ServletException {
        super.init();
        ConnectionString connString = new ConnectionString(MONGODB_URI);
        MongoClientSettings settings = MongoClientSettings.builder()
                .applyConnectionString(connString)
                .build();
        mongoClient = MongoClients.create(settings);
        MongoDatabase db = mongoClient.getDatabase(DB_NAME);
        logCollection = db.getCollection(COLLECTION_NAME);
    }

    @Override
    public void destroy() {
        if (mongoClient != null) {
            mongoClient.close();
        }
        super.destroy();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");

        // client info
        String clientIp = req.getRemoteAddr();
        String userAgent = req.getHeader("User-Agent");
        long requestStart = System.currentTimeMillis();

        String muscle = req.getParameter("muscle");
        String equipment = req.getParameter("equipment");
        String limitParam = req.getParameter("limit");

        // validation
        if (muscle == null || muscle.trim().isEmpty()) {
            String message = "missing or empty 'muscle' parameter";
            logRequest(
                    clientIp, userAgent,
                    "error", message,
                    muscle, equipment,
                    parseLimitSafe(limitParam),
                    null, -1,
                    System.currentTimeMillis() - requestStart,
                    0, 0
            );
            sendErrorJson(resp, HttpServletResponse.SC_BAD_REQUEST, message);
            return;
        }
        // if any whitespace around muscle value
        muscle = muscle.trim();

        if (equipment != null) {
            equipment = equipment.trim();
            if (equipment.equalsIgnoreCase("Any equipment") || equipment.isEmpty()) {
                equipment = null;
            }
        }

        int limit = parseLimitSafe(limitParam);

        // url for the api
        StringBuilder urlBuilder = new StringBuilder(EXERCISEDB_FILTER_URL);
        urlBuilder.append("?muscles=").append(urlEncode(muscle));
        urlBuilder.append("&limit=").append(limit);
        if (equipment != null) {
            urlBuilder.append("&equipment=").append(urlEncode(equipment));
        }
        String exerciseDbUrl = urlBuilder.toString();

        String externalJson;
        int thirdPartyStatus = -1;

        try {
            HttpURLConnection conn = null;
            BufferedReader reader = null;
            try {
                URL url = new URL(exerciseDbUrl);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);

                thirdPartyStatus = conn.getResponseCode();
                if (thirdPartyStatus != HttpURLConnection.HTTP_OK) {
                    throw new IOException("HTTP error: " + thirdPartyStatus);
                }

                reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
                externalJson = sb.toString();
            } finally {
                if (reader != null) {
                    try { reader.close(); } catch (IOException ignored) {}
                }
                if (conn != null) {
                    conn.disconnect();
                }
            }
        } catch (IOException e) {
            String message = "API unavailable: " + e.getMessage();
            logRequest(
                    clientIp, userAgent,
                    "error", message,
                    muscle, equipment,
                    limit, exerciseDbUrl,
                    thirdPartyStatus,
                    System.currentTimeMillis() - requestStart,
                    0, 0
            );
            sendErrorJson(resp, HttpServletResponse.SC_BAD_GATEWAY, message);
            return;
        }

        // parse json and reshape to cleaner response
        try {
            JSONObject payload = buildResponseJson(externalJson, muscle, equipment, limit);

            // for logging
            int totalExercises = payload.optInt("totalExercises", 0);
            int returned = 0;
            JSONArray exArr = payload.optJSONArray("exercises");
            if (exArr != null) {
                returned = exArr.length();
            }

            logRequest(
                    clientIp, userAgent,
                    "ok", null,
                    muscle, equipment,
                    limit, exerciseDbUrl,
                    thirdPartyStatus == -1 ? 200 : thirdPartyStatus,
                    System.currentTimeMillis() - requestStart,
                    totalExercises, returned
            );

            // send cleaned json to Android
            PrintWriter out = resp.getWriter();
            out.print(payload.toString());
            out.flush();

        } catch (JSONException e) {
            String message = "failed to parse external exercise data";
            logRequest(
                    clientIp, userAgent,
                    "error", message,
                    muscle, equipment,
                    limit, exerciseDbUrl,
                    thirdPartyStatus,
                    System.currentTimeMillis() - requestStart,
                    0, 0
            );
            sendErrorJson(resp, HttpServletResponse.SC_BAD_GATEWAY, message);
        } catch (Exception e) {
            String message = "server error: " + e.getMessage();
            e.printStackTrace();
            logRequest(
                    clientIp, userAgent,
                    "error", message,
                    muscle, equipment,
                    limit, exerciseDbUrl,
                    thirdPartyStatus,
                    System.currentTimeMillis() - requestStart,
                    0, 0
            );
            sendErrorJson(resp, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, message);
        }
    }

    // take json and reshape to smaller
    private JSONObject buildResponseJson(String externalJson,
                                         String muscle,
                                         String equipment,
                                         int limit) throws JSONException {

        JSONObject root = new JSONObject(externalJson);

        boolean success = root.optBoolean("success", false);
        if (!success) {
            throw new JSONException("success=false");
        }

        JSONArray dataArray = root.optJSONArray("data");
        if (dataArray == null) {
            dataArray = new JSONArray();
        }

        JSONObject metadata = root.optJSONObject("metadata");
        int totalExercises = (metadata != null)
                ? metadata.optInt("totalExercises", dataArray.length())
                : dataArray.length();

        JSONObject payload = new JSONObject();
        payload.put("status", "ok");

        JSONObject query = new JSONObject();
        query.put("muscle", muscle);
        query.put("equipment", (equipment == null ? "Any" : equipment));
        query.put("limit", limit);
        payload.put("query", query);

        payload.put("totalExercises", totalExercises);
        payload.put("returned", dataArray.length());

        JSONArray cleanedExercises = new JSONArray();
        for (int i = 0; i < dataArray.length(); i++) {
            JSONObject ex = dataArray.getJSONObject(i);
            JSONObject cleaned = new JSONObject();

            cleaned.put("name", ex.optString("name", "Unnamed exercise"));
            cleaned.put("gifUrl", ex.optString("gifUrl", ""));
            cleaned.put("targetMuscles", ex.optJSONArray("targetMuscles"));
            cleaned.put("equipments", ex.optJSONArray("equipments"));
            cleaned.put("instructions", ex.optJSONArray("instructions"));

            cleanedExercises.put(cleaned);
        }

        payload.put("exercises", cleanedExercises);
        return payload;
    }

    private void sendErrorJson(HttpServletResponse resp, int statusCode, String message)
            throws IOException {

        resp.setStatus(statusCode);
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");

        JSONObject error = new JSONObject();
        try {
            error.put("status", "error");
            error.put("message", message);
        } catch (JSONException ignored) {}

        PrintWriter out = resp.getWriter();
        out.print(error.toString());
        out.flush();
    }

    private void logRequest(String clientIp,
                            String userAgent,
                            String servletStatus,
                            String errorMessage,
                            String muscle,
                            String equipment,
                            int limit,
                            String exerciseDbUrl,
                            int thirdPartyStatus,
                            long latencyMs,
                            int totalExercisesFromApi,
                            int returnedToClient) {

        if (logCollection == null) {
            return;
        }

        try {
            Document doc = new Document()
                    .append("timestamp", Instant.now().toString())
                    .append("clientIp", clientIp)
                    .append("userAgent", userAgent)
                    .append("muscle", muscle)
                    .append("equipment", equipment == null ? "Any" : equipment)
                    .append("limit", limit)
                    .append("servletStatus", servletStatus)
                    .append("errorMessage", errorMessage)
                    .append("thirdPartyUrl", exerciseDbUrl)
                    .append("thirdPartyStatus", thirdPartyStatus)
                    .append("latencyMs", latencyMs)
                    .append("totalExercisesFromApi", totalExercisesFromApi)
                    .append("returnedToClient", returnedToClient);

            logCollection.insertOne(doc);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // for encoding of query parameter values
    private String urlEncode(String value) {
        try {
            return java.net.URLEncoder.encode(value, "UTF-8");
        } catch (Exception e) {
            return value;
        }
    }

    private int parseLimitSafe(String limitParam) {
        if (limitParam == null || limitParam.trim().isEmpty()) return 5;
        try {
            int val = Integer.parseInt(limitParam.trim());
            if (val < 1) return 5;
            if (val > 25) return 25;
            return val;
        } catch (NumberFormatException e) {
            return 5;
        }
    }
}