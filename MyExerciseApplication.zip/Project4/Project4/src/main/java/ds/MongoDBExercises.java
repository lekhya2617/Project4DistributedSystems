package ds;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.*;
import com.mongodb.client.model.Sorts;
import org.bson.Document;

import java.time.Instant;
import java.util.Scanner;

// Lekhya Reddy Rachapalli (lrachapa)
// Task 2

public class MongoDBExercises {

    private static final Gson gson = new Gson();

    private static final String MONGODB_URI =
            "mongodb+srv://lrachapa_db_user:nDEBs1z3gkAR50li@exerciseapp.yyjqpds.mongodb.net/?appName=ExerciseApp";

    private static final String DB_NAME = "project4_db";
    private static final String COLLECTION_NAME = "user_strings";

    public static void main(String[] args) {

        // build client
        MongoClientSettings settings = MongoClientSettings.builder()
                .applyConnectionString(new ConnectionString(MONGODB_URI))
                .build();

        try (MongoClient client = MongoClients.create(settings);
             Scanner scanner = new Scanner(System.in)) {

            MongoDatabase db = client.getDatabase(DB_NAME);
            MongoCollection<Document> coll = db.getCollection(COLLECTION_NAME);

            System.out.print("enter string to store: ");
            String input = scanner.nextLine().trim();

            JsonObject json = new JsonObject();
            json.addProperty("text", input);
            json.addProperty("createdAt", Instant.now().toString());

            Document toInsert = Document.parse(gson.toJson(json));
            coll.insertOne(toInsert);
            System.out.println("inserted: " + gson.toJson(json));

            // read all docs and print
            System.out.println("\nstored strings:");
            try (MongoCursor<Document> cursor =
                         coll.find().sort(Sorts.ascending("createdAt")).iterator()) {
                int i = 1;
                while (cursor.hasNext()) {
                    Document d = cursor.next();
                    JsonObject obj = gson.fromJson(d.toJson(), JsonObject.class);
                    String text = obj.has("text") ? obj.get("text").getAsString() : "(n/a)";
                    String when = obj.has("createdAt") ? obj.get("createdAt").getAsString() : "(n/a)";
                    System.out.printf("%s(createdAt=%s)%n", text, when);
                }
            }
        } catch (Exception e) {
            System.err.println(e.getMessage());
            e.printStackTrace();
        }
    }
}