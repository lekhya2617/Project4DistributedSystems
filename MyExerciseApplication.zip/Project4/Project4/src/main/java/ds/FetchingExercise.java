package ds;

import com.google.gson.*;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

// Lekhya Reddy Rachapalli (lrachapa)
// Task 1

public class FetchingExercise {

    // example: 5 ab exercises
    private static final String API_URL =
            "https://www.exercisedb.dev/api/v1/muscles/abs/exercises?offset=0&limit=5";

    public static void main(String[] args) throws IOException, InterruptedException {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(API_URL))
                .GET()
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 200) {
            System.err.println("Error: HTTP " + response.statusCode());
            System.err.println(response.body());
            return;
        }

        String json = response.body();
        Gson gson = new Gson();

        JsonElement root = JsonParser.parseString(json);
        JsonArray exercises;

        if (root.isJsonArray()) {
            exercises = root.getAsJsonArray();
        } else if (root.isJsonObject()) {
            JsonObject obj = root.getAsJsonObject();
            exercises = firstPresentArray(obj, "data", "results", "items", "exercises");
            if (exercises == null) {
                throw new JsonSyntaxException("Could not find exercises array in response object");
            }
        } else {
            throw new JsonSyntaxException("Unexpected JSON root type");
        }

        System.out.println("Found " + exercises.size() + " exercises.\n");

        int count = 0;
        for (JsonElement element : exercises) {
            if (!element.isJsonObject()) continue;
            JsonObject e = element.getAsJsonObject();

            String name = getString(e, "name");
            String equipment = getString(e, "equipments");
            String gifUrl = getString(e, "gifUrl");
            String target = getString(e, "targetMuscles");

            // format instructions array nicely with tab space before each line
            StringBuilder instructionsBuilder = new StringBuilder();
            if (e.has("instructions") && e.get("instructions").isJsonArray()) {
                JsonArray instructions = e.getAsJsonArray("instructions");
                for (JsonElement step : instructions) {
                    instructionsBuilder.append("\t").append(step.getAsString()).append("\n");
                }
            }
            // remove only the trailing newline; don't trim leading tab
            String instructionsText;
            if (instructionsBuilder.length() > 0 && instructionsBuilder.charAt(instructionsBuilder.length() - 1) == '\n') {
                instructionsText = instructionsBuilder.substring(0, instructionsBuilder.length() - 1);
            } else {
                instructionsText = instructionsBuilder.toString();
            }

            System.out.printf(
                    "Name: %s\nEquipment: %s\nTarget: %s\nGIF: %s\nInstructions:\n%s%n%n",
                    nvl(name), nvl(equipment), nvl(target), nvl(gifUrl),
                    instructionsText.isEmpty() ? "(n/a)" : instructionsText
            );

            if (++count >= 5) break;
        }
    }

    /** Return the first array field that exists, else null. */
    private static JsonArray firstPresentArray(JsonObject obj, String... keys) {
        for (String k : keys) {
            if (obj.has(k) && obj.get(k).isJsonArray()) {
                return obj.getAsJsonArray(k);
            }
        }
        return null;
    }

    /** Safely get a string from any of the candidate keys. */
    private static String getString(JsonObject obj, String... keys) {
        for (String k : keys) {
            if (obj.has(k) && obj.get(k).isJsonPrimitive()) {
                JsonPrimitive p = obj.getAsJsonPrimitive(k);
                if (p.isString()) return p.getAsString();
                if (obj.get(k).isJsonArray()) {
                    JsonArray arr = obj.getAsJsonArray(k);
                    if (arr.size() > 0 && arr.get(0).isJsonPrimitive()) {
                        return arr.get(0).getAsString();
                    }
                }
            } else if (obj.has(k) && obj.get(k).isJsonArray()) {
                JsonArray arr = obj.getAsJsonArray(k);
                if (arr.size() > 0 && arr.get(0).isJsonPrimitive()) {
                    return arr.get(0).getAsString();
                }
            }
        }
        return null;
    }

    private static String nvl(String s) { return (s == null || s.isBlank()) ? "(n/a)" : s; }
}