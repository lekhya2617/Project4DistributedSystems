// Author: Lekhya Reddy Rachapalli (lrachapa)

package com.example.myexerciseapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.graphics.Color;
import android.text.Editable;
import android.text.TextWatcher;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.ImageView;
import android.app.AlertDialog;
import android.view.LayoutInflater;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.constraintlayout.widget.ConstraintLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

// gif imports
import com.bumptech.glide.Glide;

public class MainActivity extends AppCompatActivity {

    // deployed servlet in codespaces
    private static final String BASE_URL = "https://fuzzy-tribble-r4654xj577gjcp9w4-8080.app.github.dev/exerciseapp/api/exercises";

    // widgets for filters and inputs
    private Spinner spinnerMuscle;
    private Spinner spinnerEquipment;
    private EditText exerciseLimit;
    private Button fetchExercise;
    private TextView statusText;
    private ListView listOfExercises;

    // custom adapter
    private ExerciseAdapter exerciseAdapter;
    private List<Exercise> exerciseList = new ArrayList<>();

    // for centering/moving controls
    private ConstraintLayout rootLayout;
    private View controlsContainer;

    // to get back original text color after invalid input
    private int originalLimitTextColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // force dark mode
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ui components from xml
        spinnerMuscle = findViewById(R.id.spinnerMuscle);
        spinnerEquipment = findViewById(R.id.spinnerEquipment);
        setupEquipmentSpinner();
        exerciseLimit = findViewById(R.id.exerciseLimit);
        fetchExercise = findViewById(R.id.fetchExercise);
        statusText = findViewById(R.id.statusText);
        listOfExercises = findViewById(R.id.listOfExercises);

        rootLayout = findViewById(R.id.rootLayout);
        controlsContainer = findViewById(R.id.controlsContainer);

        // making the fields centered and list hidden
        listOfExercises.setVisibility(View.GONE);
        setControlsCentered(true);

        originalLimitTextColor = exerciseLimit.getCurrentTextColor();
        // validation for the limit field
        setupLimitValidation();

        setupMuscleSpinner();

        exerciseAdapter = new ExerciseAdapter(this, exerciseList);
        listOfExercises.setAdapter(exerciseAdapter);

        // after clicking Find Exercises
        fetchExercise.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fetchExercises();
            }
        });

        // to display modal
        listOfExercises.setOnItemClickListener((parent, view, position, id) -> {
            Exercise ex = exerciseList.get(position);
            showExerciseDialog(ex);
        });
    }

    private void showExerciseDialog(Exercise ex) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_exercise_details, null);
        builder.setView(dialogView);

        TextView nameText = dialogView.findViewById(R.id.tvDialogName);
        ImageView imgGif = dialogView.findViewById(R.id.imgDialogGif);
        TextView targetText = dialogView.findViewById(R.id.tvDialogTarget);
        TextView equipmentText = dialogView.findViewById(R.id.tvDialogEquipment);
        TextView instructionText = dialogView.findViewById(R.id.tvDialogInstructions);

        nameText.setText(capitalizeWords(ex.getName()));
        targetText.setText("Target: " + ex.getTargetMuscles());
        equipmentText.setText("Equipment: " + ex.getEquipments());
        instructionText.setText(ex.getFirstInstruction());

        String gifUrl = ex.getGifUrl();

        // gif handling w glide
        if (gifUrl != null && !gifUrl.isEmpty()) {
            Glide.with(this)
                    .asGif()
                    .load(gifUrl)
                    .into(imgGif);
        } else {
            // if no gif, to hide the image view
            imgGif.setVisibility(View.GONE);
        }

        builder.setPositiveButton("Close", (d, w) -> d.dismiss());

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    // levator scapulae: neck
    // serratus anterior: chest
    // upper back: back
    // pectorals: chest
    // removed everything that doesn't result in tangible results and removed unnecessary/unknown muscles
    private void setupMuscleSpinner() {
        // All muscles you want in the dropdown
        String[] muscles = new String[]{
//                "shins",
//                "hands",
//                "sternocleidomastoid",
//                "soleus",
//                "inner thighs",
//                "lower abs",
//                "grip muscles",
//                "abdominals",
//                "wrist extensors",
//                "wrist flexors",
//                "latissimus dorsi",
//                "upper chest",
//                "rotator cuff",
//                "wrists",
//                "groin",
//                "brachialis",
//                "deltoids",
//                "feet",
//                "ankles",
//                "trapezius",
//                "rear deltoids",
//                "chest",
//                "quadriceps",
//                "back",
//                "core",
//                "shoulders",
//                "ankle stabilizers",
//                "rhomboids",
//                "obliques",
//                "lower back",
//                "hip flexors",
                "abductors",
                "levator scapulae",
                "serratus anterior",
                "traps",
//                "forearms",
//                "delts",
                "biceps",
                "upper back",
//                "spine",
                "cardiovascular system",
                "triceps",
                "adductors",
                "hamstrings",
                "glutes",
                "pectorals",
                "calves",
                "lats",
                "quads",
                "abs"
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                muscles
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerMuscle.setAdapter(adapter);
    }

    // removed everything that doesn't result in tangible results and removed unnecessary/unknown equipment
    private void setupEquipmentSpinner() {
        String[] equipment = new String[]{
//                "stepmill machine",
//                "elliptical machine",
//                "trap bar",
//                "tire",
//                "stationary bike",
//                "wheel roller",
                "any equipment",
                "smith machine",
//                "hammer",
//                "skierg machine",
                "roller",
                "resistance band",
                "bosu ball",
                "weighted",
//                "olympic barbell",
                "kettlebell",
//                "upper body ergometer",
//                "sled machine",
                "ez barbell",
                "dumbbell",
                "rope",
                "barbell",
//                "band",
                "stability ball",
                "medicine ball",
                "assisted",
                "leverage machine",
                "cable",
                "body weight"
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                equipment
        );

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerEquipment.setAdapter(adapter);
    }

    private void setupLimitValidation() {
        exerciseLimit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                String text = s.toString().trim();

                if (text.isEmpty()) {
                    exerciseLimit.setTextColor(originalLimitTextColor);
                    fetchExercise.setEnabled(true);
                    statusText.setText("Retrieving 5 exercises if left blank");
                    return;
                }

                int value;
                // if the parse fails we assume invalid and block requests
                try {
                    value = Integer.parseInt(text);
                } catch (NumberFormatException e) {
                    exerciseLimit.setTextColor(Color.RED);
                    fetchExercise.setEnabled(false);
                    statusText.setText("Invalid input");
                    return;
                }

                if (value < 1 || value > 25) {
                    exerciseLimit.setTextColor(Color.RED);
                    fetchExercise.setEnabled(false);
                    statusText.setText("Please enter a number between 1 and 25");
                } else {
                    exerciseLimit.setTextColor(originalLimitTextColor);
                    fetchExercise.setEnabled(true);
                    statusText.setText("Ready to search.");
                }
            }
        });
    }

    private void fetchExercises() {
        String muscle = spinnerMuscle.getSelectedItem().toString();
        String equipment = spinnerEquipment.getSelectedItem().toString();

        String limitStr = exerciseLimit.getText().toString().trim();
        int limit;

        // default is 5 if empty or invalid
        if (limitStr.isEmpty()) {
            limit = 5;
        } else {
            try {
                limit = Integer.parseInt(limitStr);
            } catch (Exception e) {
                limit = 5;
            }
        }

        // for safety reasons
        if (limit < 1) limit = 5;
        if (limit > 25) limit = 25;

        try {
            // handling muscle names with spaces
            String encodedMuscle = android.net.Uri.encode(muscle);

            StringBuilder urlBuilder = new StringBuilder(BASE_URL);
            urlBuilder.append("?muscle=").append(encodedMuscle);
            urlBuilder.append("&limit=").append(limit);

            // only send equipment if it's NOT "any equipment"
            if (!equipment.trim().equalsIgnoreCase("any equipment")) {
                String encodedEquipment = android.net.Uri.encode(equipment);
                urlBuilder.append("&equipment=").append(encodedEquipment);
            }

            String urlString = urlBuilder.toString();

            // debugging statement
            // statusText.setText("Requesting:\n" + urlString);
            new FetchExercisesTask().execute(urlString);

        } catch (Exception e) {
            statusText.setText("Error fetching from: " + e.getMessage());
        }
    }

    // background networking thread
    private class FetchExercisesTask extends AsyncTask<String, Void, String> {

        private String errorMessage = null;

        @Override
        protected String doInBackground(String... params) {
            String urlString = params[0];
            HttpURLConnection conn = null;
            BufferedReader reader = null;

            try {
                URL url = new URL(urlString);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);

                // for non-200
                int responseCode = conn.getResponseCode();
                if (responseCode != HttpURLConnection.HTTP_OK) {
                    errorMessage = "HTTP error: " + responseCode;
                    return null;
                }

                InputStream inputStream = conn.getInputStream();
                StringBuilder sb = new StringBuilder();
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }

                return sb.toString();

            } catch (IOException e) {
                errorMessage = "Network error: " + e.getMessage();
                return null;
            } finally {
                if (reader != null) {
                    try { reader.close(); } catch (IOException ignored) {}
                }
                if (conn != null) conn.disconnect();
            }
        }

        @Override
        protected void onPostExecute(String jsonString) {
            super.onPostExecute(jsonString);

            if (errorMessage != null) {
                statusText.setText(errorMessage);
                exerciseList.clear();
                exerciseAdapter.notifyDataSetChanged();
                return;
            }

            if (jsonString == null || jsonString.isEmpty()) {
                // debugging
                // statusText.setText("Empty response from server.");
                statusText.append("\n\nEmpty JSON");
                exerciseList.clear();
                exerciseAdapter.notifyDataSetChanged();
                return;
            }

            // debugging: fixed by changing pirt to public
            String trimmed = jsonString.trim();
            if (!trimmed.startsWith("{") && !trimmed.startsWith("[")) {
                int maxLen = Math.min(300, trimmed.length());
                statusText.append(
                        "\n\nfirst part of response:\n"
                                + trimmed.substring(0, maxLen)
                );
                exerciseList.clear();
                exerciseAdapter.notifyDataSetChanged();
                return;
            }

            try {
                parseAndDisplay(jsonString);
            } catch (JSONException e) {
                // debugging; trying to see what the error is
                // statusText.setText("JSON parse error: " + e.getMessage());
                statusText.append("\n\nJSON parse error: " + e.getMessage());
                exerciseList.clear();
                exerciseAdapter.notifyDataSetChanged();
            }
        }
    }

    // to parse the json from servlet
    private void parseAndDisplay(String jsonString) throws JSONException {

        JSONObject root = new JSONObject(jsonString);

        // changing to check for status from servlet. before that we were checking success from json
        String status = root.optString("status", "ok");
        if (!"ok".equalsIgnoreCase(status)) {
            statusText.append("\n\nAPI status: " + status);
            exerciseList.clear();
            exerciseAdapter.notifyDataSetChanged();
            return;
        }

        JSONArray dataArray = root.optJSONArray("exercises");
        if (dataArray == null || dataArray.length() == 0) {
            statusText.append("\n\nNo exercises found.");
            exerciseList.clear();
            exerciseAdapter.notifyDataSetChanged();
            listOfExercises.setVisibility(View.GONE);
            setControlsCentered(true);
            return;
        }

        // total number of available exercises
        int totalExercises = root.optInt("totalExercises", dataArray.length());

        exerciseList.clear();

        for (int i = 0; i < dataArray.length(); i++) {
            JSONObject exObj = dataArray.getJSONObject(i);

            String name = exObj.optString("name", "Unnamed exercise");

            JSONArray targetArray = exObj.optJSONArray("targetMuscles");
            StringBuilder targetBuilder = new StringBuilder();
            if (targetArray != null) {
                for (int t = 0; t < targetArray.length(); t++) {
                    if (t > 0) targetBuilder.append(", ");
                    targetBuilder.append(targetArray.optString(t));
                }
            }

            JSONArray equipArray = exObj.optJSONArray("equipments");
            StringBuilder equipBuilder = new StringBuilder();
            if (equipArray != null) {
                for (int e = 0; e < equipArray.length(); e++) {
                    if (e > 0) equipBuilder.append(", ");
                    equipBuilder.append(equipArray.optString(e));
                }
            }

            // instructions is array of strings so we need to join everything w \n
            JSONArray instrArray = exObj.optJSONArray("instructions");
            StringBuilder instrBuilder = new StringBuilder();
            if (instrArray != null) {
                for (int j = 0; j < instrArray.length(); j++) {
                    if (j > 0) instrBuilder.append("\n\n");
                    instrBuilder.append(instrArray.optString(j));
                }
            }
            String instructions = instrBuilder.toString();

            String gifUrl = exObj.optString("gifUrl", "");

            Exercise exercise = new Exercise(
                    name,
                    targetBuilder.toString(),
                    equipBuilder.toString(),
                    instructions,
                    gifUrl
            );
            exerciseList.add(exercise);
        }

        // summary
        statusText.setText("Displaying " + exerciseList.size() + "/" + totalExercises + " exercises.");
        listOfExercises.setVisibility(View.VISIBLE);
        setControlsCentered(false);
        exerciseAdapter.notifyDataSetChanged();
    }
    private void setControlsCentered(boolean centered) {
        if (controlsContainer == null) return;

        ConstraintLayout.LayoutParams params =
                (ConstraintLayout.LayoutParams) controlsContainer.getLayoutParams();

        params.verticalBias = centered ? 0.4f : 0.0f;
        controlsContainer.setLayoutParams(params);
    }

    private String capitalizeWords(String input) {
        if (input == null || input.isEmpty()) return input;

        StringBuilder result = new StringBuilder(input.length());
        boolean newWord = true;

        // capitalize first letter of each word
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);

            if (Character.isWhitespace(c)) {
                newWord = true;
                result.append(c);
            } else {
                if (newWord) {
                    result.append(Character.toUpperCase(c));
                    newWord = false;
                } else {
                    result.append(Character.toLowerCase(c));
                }
            }
        }
        return result.toString();
    }
}