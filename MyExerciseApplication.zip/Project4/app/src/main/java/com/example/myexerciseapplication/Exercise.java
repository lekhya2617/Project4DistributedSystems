// Author: Lekhya Reddy Rachapalli (lrachapa)

package com.example.myexerciseapplication;
public class Exercise {

    private String name;
    private String targetMuscles;
    private String equipments;
    private String firstInstruction;
    private String gifUrl;

    // constructor
    public Exercise(String name, String targetMuscles, String equipments, String firstInstruction, String gifUrl) {
        this.name = name;
        this.targetMuscles = targetMuscles;
        this.equipments = equipments;
        this.firstInstruction = firstInstruction;
        this.gifUrl = gifUrl;
    }

    // getters
    public String getName() {
        return name;
    }

    public String getTargetMuscles() {
        return targetMuscles;
    }

    public String getEquipments() {
        return equipments;
    }

    public String getFirstInstruction() {
        return firstInstruction;
    }

    public String getGifUrl() {
        return gifUrl;
    }
}