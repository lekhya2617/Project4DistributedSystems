// Author: Lekhya Reddy Rachapalli (lrachapa)

package com.example.myexerciseapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

// adapter to render each exercise

public class ExerciseAdapter extends ArrayAdapter<Exercise> {

    public ExerciseAdapter(@NonNull Context context, @NonNull List<Exercise> exercises) {
        super(context, 0, exercises);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View row = convertView;
        if (row == null) {
            row = LayoutInflater.from(getContext())
                    .inflate(R.layout.exercise_card, parent, false);
        }

        TextView tvName = row.findViewById(R.id.tvExerciseName);

        // exercise object for the current row
        Exercise ex = getItem(position);
        if (ex != null) {
            // using title case
            tvName.setText(capitalizeWords(ex.getName()));
        }
        // return listview
        return row;
    }

    // helper for title case
    private String capitalizeWords(String input) {
        if (input == null || input.isEmpty()) return input;

        StringBuilder result = new StringBuilder(input.length());
        boolean newWord = true;

        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);

            if (Character.isWhitespace(c)) {
                newWord = true;
                result.append(c);
            } else {
                if (newWord) {
                    result.append(Character.toUpperCase(c));
                    newWord = false;
                } else {
                    result.append(Character.toLowerCase(c));
                }
            }
        }

        return result.toString();
    }
}